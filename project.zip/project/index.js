const express =require("express")
const bodyParser = require("body-parser");
const https = require("https");
const mongoose = require("mongoose");
const multer = require("multer");
const path = require("path");
const router = express.Router();
const app = express();

mongoose.connect("mongodb+srv://ngo-website:SID120699@cluster0.2ikfg.mongodb.net/ngoDB",{ useNewUrlParser: true,useUnifiedTopology: true })

const BlogSchema=mongoose.Schema({
    Image:"String",
    Title:"String",
    Content:"String",
    EventDay:"Date"
});
const Joinschema =mongoose.Schema({
    Name:"String",
    Email:"String",
    MOB:"Number"
});
const Blog =mongoose.model("Blog",BlogSchema);
const Join =mongoose.model("Join",Joinschema);

app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static("public"));
app.set("view engine","ejs");



app.get("/",function(req,res){
    res.render("index");
});
app.post("/",function(req,res){
    const Newsletter= req.body.newsletter;
    const data={
        members:[
            {
                email_address:Newsletter,
                status:"subscribed"
            }
        ]
    };
    const jsonData = JSON.stringify(data);
    const url="https://us4.api.mailchimp.com/3.0/lists/a724eb4416";
    const options={
        method:"POST",
        auth:"NGO:00e54ce8f8cf5acdbbca4ca9bdd27520-us4"
    }
    const request =  https.request(url,options,function(response){
        response.on("data",function(data){

            console.log(JSON.parse(data));
        })
    })
    request.write(jsonData);
    request.end();
    res.redirect("/");
    
})
app.get("/blog",function(req,res){
    Blog.find({},function(err,result){
        if(!err)
        {
            res.render("blog",{title:"Events",titles:result});
        }
    })
   

});

var Storage = multer.diskStorage({
    destination:"./public/upload",
    filename:function(req,file,cb){
        cb(null,file.fieldname+"_"+Date.now()+path.extname(file.originalname));
    }
})

var upload = multer({
    storage:Storage
}).single("photo");


app.get("/compose",function(req,res){
    res.render("compose",{title:"compose"})
});
app.post("/compose",upload,function(req,res){
    const newBlog = new Blog({
        Image:req.file.filename,
        Title:req.body.Title,
        Content:req.body.content,
        EventDay:req.body.EventDay
    });
    newBlog.save();
    res.redirect("/blog")
})


app.get("/about",function(req,res){
    res.render("about",{title:"About"});
});
app.get("/cause",function(req,res){
    res.render("causes",{title:"OUR CAUSES"});
})
app.get("/join",function(req,res){
    res.render("join")
})
app.post("/join",function(req,res){
    const newJoin =new Join({
        Name:req.body.Name,
        Email:req.body.emailAddress,
        MOB:req.body.phone
    })
    newJoin.save();
    res.render("sucess")

})
app.get("/members",function(req,res){
    Join.find({},function(err,result){
        if(!err)
        {
            res.render("members",{titles:result})
        }
        
    })
})
   
app.get("/galary",function(req,res){
    res.render("galary")
})

app.get("/delete",function(req,res){
    res.render("delete");
})
app.post("/delete",function(req,res){
    Blog.deleteOne({Title:req.body.title},function(err){
        if(!err)
        res.redirect("/blog")
    })
})
app.get("/admin",function(req,res){
    res.render("admin");
})

app.listen(process.env.PORT|| 3000,function(){
    console.log("server started")
})

// 
// mongodb+srv://ngo-website:SID120699@cluster0.2ikfg.mongodb.net/ngoDB